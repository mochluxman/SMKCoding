package com.bagicode.www.bagisliderview._sliders

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView

import com.bagicode.www.bagisliderview.R
import com.bumptech.glide.Glide

/**
 * Created by bagicode on 12/04/17.
 */

class FragmentSlider : Fragment() {

    private var imageUrls: String? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        imageUrls = arguments.getString(ARG_PARAM1)
        val view = inflater.inflate(R.layout.fragment_slider_item, container, false)
        val img = view.findViewById<View>(R.id.img) as ImageView
        Glide.with(activity)
                .load(imageUrls)
                .placeholder(R.drawable.image_slider_1)
                .into(img)
        return view
    }

    companion object {

        private val ARG_PARAM1 = "params"

        fun newInstance(params: String): FragmentSlider {
            val fragment = FragmentSlider()
            val args = Bundle()
            args.putString(ARG_PARAM1, params)
            fragment.arguments = args
            return fragment
        }
    }
}