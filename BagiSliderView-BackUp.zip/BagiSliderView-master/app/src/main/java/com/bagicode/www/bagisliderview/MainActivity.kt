package com.bagicode.www.bagisliderview

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.LinearLayout

import com.bagicode.www.bagisliderview._sliders.FragmentSlider
import com.bagicode.www.bagisliderview._sliders.SliderIndicator
import com.bagicode.www.bagisliderview._sliders.SliderPagerAdapter
import com.bagicode.www.bagisliderview._sliders.SliderView

import java.util.ArrayList

class MainActivity : AppCompatActivity() {

    private var mAdapter: SliderPagerAdapter? = null
    private var mIndicator: SliderIndicator? = null

    private var sliderView: SliderView? = null
    private var mLinearLayout: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sliderView = findViewById<View>(R.id.sliderView) as SliderView?
        mLinearLayout = findViewById<View>(R.id.pagesContainer) as LinearLayout?
        setupSlider()
    }


    private fun setupSlider() {
        sliderView!!.setDurationScroll(800)
        val fragments = ArrayList<Fragment>()
        fragments.add(FragmentSlider.newInstance("http://www.menucool.com/slider/prod/image-slider-1.jpg"))
        fragments.add(FragmentSlider.newInstance("http://www.menucool.com/slider/prod/image-slider-2.jpg"))
        fragments.add(FragmentSlider.newInstance("http://www.menucool.com/slider/prod/image-slider-3.jpg"))
        fragments.add(FragmentSlider.newInstance("http://www.menucool.com/slider/prod/image-slider-4.jpg"))

        mAdapter = SliderPagerAdapter(supportFragmentManager, fragments)
        sliderView!!.adapter = mAdapter
        mIndicator = SliderIndicator(this, mLinearLayout!!, sliderView!!, R.drawable.indicator_circle)
        mIndicator!!.setPageCount(fragments.size)
        mIndicator!!.show()
    }
}
